# node-probe

Diagnostic probe for hosts and networks.

## Configuration

| Key | Description | Default |
|-----|-------------|---------|
| `telemetry.servicePort` | Port exposed by the Service to scrapers | `80` |
| `telemetry.scrapeInterval` | Advertised scrape interval | `30s` |
| `replicaCount` | Number of probe pods | `1` |

## Example

```yaml
telemetry:
  servicePort: 9100
```
